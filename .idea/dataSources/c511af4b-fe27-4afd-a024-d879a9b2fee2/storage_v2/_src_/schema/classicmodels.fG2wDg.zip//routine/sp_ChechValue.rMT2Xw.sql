create
    definer = root@localhost procedure sp_ChechValue(IN value1 int, OUT value2 int)
begin
   set value2=(select Amount from SumOfAll where Amount=value1);
   end;

